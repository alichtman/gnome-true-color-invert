# Development Notes

## Current Issue: Keyboard Shortcut Not Registering in Preferences UI

### Problem
User created a preferences UI for setting keyboard shortcuts, but setting a new keyboard shortcut doesn't work.

### Root Causes Found

1. **Extension not listening for setting changes** (FIXED)
   - The extension only registered the keybinding once on enable()
   - When the setting changed in prefs, the running extension didn't know
   - Fixed by adding a signal handler in extension.js:81-91 that listens for `changed::invert-window-shortcut` and re-registers the keybinding

2. **Keyboard capture in prefs UI not working** (IN PROGRESS)
   - User reports they can't get a new keybinding to register at all in the settings menu
   - Added debugging console.log statements to track key presses
   - Changed from Gtk.keyval_from_name() to Gdk.KEY_* constants (more reliable)
   - Added proper event return values (Gdk.EVENT_STOP vs Gdk.EVENT_PROPAGATE)
   - Added Escape key handling to cancel dialog
   - Need to test if keyboard events are being captured at all

### Changes Made

**extension.js:**
- Line 70: Changed `extensionSettings` to `this._extensionSettings` to store as instance variable
- Lines 81-91: Added signal handler for keybinding changes that removes and re-adds the keybinding
- Lines 162-164: Added cleanup for the signal handler in disable()

**prefs.js:**
- Line 4: Added `import Gdk from 'gi://Gdk';`
- Lines 115-148: Rewrote keyboard capture handler with:
  - Console logging for debugging
  - Gdk key constants instead of Gtk.keyval_from_name()
  - Proper event return values
  - Escape key handling

### Next Steps
1. Test if keyboard events are being captured in the dialog
2. Check console logs to see what's happening when keys are pressed
3. May need to ensure dialog has focus or use different event capture method
4. Consider using Adw.MessageDialog or different approach if GTK event capture is problematic

### Files Involved
- `/home/alichtman/Desktop/Development/projects/gnome-true-color-invert/prefs.js` - Preferences UI
- `/home/alichtman/Desktop/Development/projects/gnome-true-color-invert/extension.js` - Main extension
- `/home/alichtman/Desktop/Development/projects/gnome-true-color-invert/schemas/org.gnome.shell.extensions.true-color-window-invert.gschema.xml` - Settings schema
